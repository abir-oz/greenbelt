<?php
/*
Plugin Name:  Green Belt Custom Post
Plugin URI:
Author: Abir
Author URI: fb.com/aabirr.oz
Description: Greenbelt Custom Post Type
Version: 1.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: greenbelt-cpt
*/



function greenbelt_register_cpts() {

    /**
     * Post Type: Traveler's Blogs.
     */

    $labels = [
        "name" => __( "Traveler's Blogs", "greenbelt" ),
        "singular_name" => __( "Traveler's Blog", "greenbelt" ),
        "menu_name" => __( "Traveler's blog", "greenbelt" ),
        "all_items" => __( "All blog", "greenbelt" ),
    ];

    $args = [
        "label" => __( "Traveler's Blogs", "greenbelt" ),
        "labels" => $labels,
        "description" => "Traveler\'s blog will go here",
        "public" => true,
        "publicly_queryable" => true,
        "show_ui" => true,
        "show_in_rest" => true,
        "rest_base" => "",
        "rest_controller_class" => "WP_REST_Posts_Controller",
        "has_archive" => true,
        "show_in_menu" => true,
        "show_in_nav_menus" => true,
        "delete_with_user" => false,
        "exclude_from_search" => false,
        "capability_type" => "post",
        "map_meta_cap" => true,
        "hierarchical" => false,
        "rewrite" => [ "slug" => "travblog", "with_front" => true ],
        "query_var" => true,
        "menu_position" => 8,
        "menu_icon" => "dashicons-palmtree",
        "supports" => [ "title", "editor", "thumbnail", "excerpt", "custom-fields", "comments", "revisions", "author", "page-attributes", "post-formats" ],
        "taxonomies" => [ "post_tag" ],
    ];

    register_post_type( "travblog", $args );

    /**
     * Post Type: Tour Packages.
     */

    $labels = [
        "name" => __( "Tour Packages", "greenbelt" ),
        "singular_name" => __( "Tour Package", "greenbelt" ),
        "menu_name" => __( "Tour Package", "greenbelt" ),
        "all_items" => __( "All Tour Packages", "greenbelt" ),
    ];

    $args = [
        "label" => __( "Tour Packages", "greenbelt" ),
        "labels" => $labels,
        "description" => "",
        "public" => true,
        "publicly_queryable" => true,
        "show_ui" => true,
        "show_in_rest" => true,
        "rest_base" => "",
        "rest_controller_class" => "WP_REST_Posts_Controller",
        "has_archive" => true,
        "show_in_menu" => true,
        "show_in_nav_menus" => true,
        "delete_with_user" => false,
        "exclude_from_search" => false,
        "capability_type" => "post",
        "map_meta_cap" => true,
        "hierarchical" => false,
        "rewrite" => [ "slug" => "tourpackage", "with_front" => true ],
        "query_var" => true,
        "menu_position" => 7,
        "menu_icon" => "dashicons-tickets",
        "supports" => [ "title", "editor", "thumbnail", "excerpt", "custom-fields", "comments", "revisions", "author", "page-attributes", "post-formats" ],
        "taxonomies" => ["post_tag" ],
    ];

    register_post_type( "tourpackage", $args );

    /**
     * Post Type: Sliders.
     */

    $labels = [
        "name" => __( "Sliders", "greenbelt" ),
        "singular_name" => __( "Slider", "greenbelt" ),
        "all_items" => __( "All Sliders", "greenbelt" ),
        "add_new_item" => __( "Add New Slider", "greenbelt" ),
        "edit_item" => __( "Edit Slider", "greenbelt" ),
        "new_item" => __( "New Slider", "greenbelt" ),
        "view_item" => __( "View Slider", "greenbelt" ),
        "view_items" => __( "View Sliders", "greenbelt" ),
        "featured_image" => __( "Slider Image", "greenbelt" ),
        "set_featured_image" => __( "Set Slider Image", "greenbelt" ),
        "remove_featured_image" => __( "Remove Slider Image", "greenbelt" ),
    ];

    $args = [
        "label" => __( "Sliders", "greenbelt" ),
        "labels" => $labels,
        "description" => "",
        "public" => true,
        "publicly_queryable" => true,
        "show_ui" => true,
        "show_in_rest" => true,
        "rest_base" => "",
        "rest_controller_class" => "WP_REST_Posts_Controller",
        "has_archive" => false,
        "show_in_menu" => true,
        "show_in_nav_menus" => true,
        "delete_with_user" => false,
        "exclude_from_search" => true,
        "capability_type" => "post",
        "map_meta_cap" => true,
        "hierarchical" => false,
        "rewrite" => [ "slug" => "greenbeltslider", "with_front" => false ],
        "query_var" => true,
        "menu_position" => 5,
        "menu_icon" => "dashicons-format-image",
        "supports" => [ "title", "editor", "thumbnail" ],
    ];

    register_post_type( "greenbeltslider", $args );

    /**
     * Post Type: Testimonials.
     */

    $labels = [
        "name" => __( "Testimonials", "greenbelt" ),
        "singular_name" => __( "Testimonial", "greenbelt" ),
        "menu_name" => __( "Testimonials", "greenbelt" ),
    ];

    $args = [
        "label" => __( "Testimonials", "greenbelt" ),
        "labels" => $labels,
        "description" => "",
        "public" => true,
        "publicly_queryable" => true,
        "show_ui" => true,
        "show_in_rest" => true,
        "rest_base" => "",
        "rest_controller_class" => "WP_REST_Posts_Controller",
        "has_archive" => false,
        "show_in_menu" => true,
        "show_in_nav_menus" => true,
        "delete_with_user" => false,
        "exclude_from_search" => true,
        "capability_type" => "post",
        "map_meta_cap" => true,
        "hierarchical" => false,
        "rewrite" => [ "slug" => "testimonial", "with_front" => true ],
        "query_var" => true,
        "menu_position" => 9,
        "menu_icon" => "dashicons-format-status",
        "supports" => [ "title", "editor", "thumbnail" ],
    ];

    register_post_type( "testimonial", $args );
}

add_action( 'init', 'greenbelt_register_cpts' );

function greenbelt_cpt_tags_author( $query ) {
    if ( $query->is_tag() && $query->is_main_query() ) {
        $query->set( 'post_type', array( 'post','tourpackage','travblog') );
    }
}
add_action( 'pre_get_posts', 'greenbelt_cpt_tags_author' );
